import UIKit


struct Game {
    var moves: [String:String]?// = ["playerOneId":"idle","playerTwoId":""]
}

var game = Game()


// Player one Make move
if game.moves != nil {
    var newMoves = game.moves!
    newMoves["playerOneId"] = "rock"
    game.moves = newMoves
} else {
    let newMoves = ["playerOneId":"rock"]
    game.moves = newMoves
}

// Player two gets callback and game object is update with the first players move

if game.moves != nil {
    var newMoves = game.moves!
    newMoves["playerTwoId"] = "paper"
    game.moves = newMoves
} else {
    let newMoves = ["playerTwoId":"paper"]
    game.moves = newMoves
}

game.moves



